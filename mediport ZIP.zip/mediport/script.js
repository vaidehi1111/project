var modal_login = document.getElementById('login-modal');
var loginBtn = document.getElementById('login-btn');
var closeBtn = document.querySelector('.close-btn');
var login = document.getElementById("login");
var register_form = document.getElementById("register_formbtn");
var register_container = document.getElementById('register-container');
var form_title = document.getElementById('form-title');
var login_form = document.getElementById('login_form');

// Show the login modal when the login button is clicked
loginBtn.addEventListener('click', function(event) {
    event.preventDefault(); 
    modal_login.style.display = 'block';
    register_container.style.display = 'none'; // Hide register container on login
    form_title.textContent = 'Login'; // Update title to Login
});

// Handle login submission
login.addEventListener('click', function(event) {
    event.preventDefault();
    alert("Login successful");
    window.location.href = './login.html';  // Update this with the actual path to your success page
});

// Close modal when close button is clicked
closeBtn.addEventListener('click', function() {
    modal_login.style.display = 'none';
});

// Close modal when clicking outside the modal
window.addEventListener('click', function(event) {
    if (event.target == modal_login) {
        modal_login.style.display = 'none';
    }
});

// Show register form when "Register here" link is clicked
register_form.addEventListener('click', function(event) {
    event.preventDefault();
    register_container.style.display = 'block'; // Show register container
    form_title.textContent = 'Register'; // Update title to Register
});

// Show login form when "Login here" link is clicked
document.getElementById('show-login').addEventListener('click', function(event) {
    event.preventDefault();
    register_container.style.display = 'none'; // Hide register container
    form_title.textContent = 'Login'; // Update title to Login
});
