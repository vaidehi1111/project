<?php 
$conn = mysqli_connect('localhost', 'u396395651_mediport', '$Q4fk|d0Q4' , 'u396395651_mediport');

?>