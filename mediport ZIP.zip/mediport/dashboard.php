<?php
session_start();  
if (isset($_SESSION['user_id']) && isset($_SESSION['user_name'])) {
     
} else {
    header("Location: index.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <!-- Sidebar Navigation -->
        <nav class="sidebar">
            <div class="sidebar-header">
                <h2>My Dashboard</h2>
            </div>
            <ul class="sidebar-menu">
                <li><a href="dashboard.php">Dashboard</a></li> 
                <li><a href="reports.php">Reports</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </nav>

        <!-- Main Content -->
        <div class="main-content">
            <!-- Header -->
            <header class="header">
                <h1>Hello, <?php echo $_SESSION['user_name']; ?></h1>
                <a class="logout-btn" href="logout.php">Logout</a>
            </header>

            <!-- Dashboard Widgets -->
            <section class="dashboard-widgets">
                <div class="widget card">
                    <h3>Total Reports</h3>
                    <p>3</p>
                </div> 
            </section>
        </div>
    </div>
</body>
</html>

