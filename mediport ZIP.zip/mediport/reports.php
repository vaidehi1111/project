<?php
session_start();  
if (isset($_SESSION['user_id']) && isset($_SESSION['user_name'])) {
     
} else {
    header("Location: index.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        td{
            padding : 10px;
        }
        .print-btn{
            width: 100px;
                height: 30px;
                background: cadetblue;
                border: 2px solid black;
                border-radius: 7px;
                padding: 3px 25px;
    color: white;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Sidebar Navigation -->
        <nav class="sidebar">
            <div class="sidebar-header">
                <h2>My Dashboard</h2>
            </div>
            <ul class="sidebar-menu">
                <li><a href="dashboard.php">Dashboard</a></li> 
                <li><a href="reports.php">Reports</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </nav>

        <!-- Main Content -->
        <div class="main-content">
            <!-- Header -->
            <header class="header">
                <h1>Hello, <?php echo $_SESSION['user_name']; ?></h1>
                <a class="logout-btn" href="logout.php">Logout</a>
            </header> 
            <!-- Table Section -->
            <section class="table-section" style="margin-top : 10px">
                <h2>My Reports</h2>
                <table class="dashboard-table" style="width : 100%; margin-top : 10px; border-collapse: collapse; cellpaddi" border="1px">
                    <thead>
                        <tr>
                            <th>SL</th>
                            <th>Report ID</th>
                            <th>Collection Date</th>
                            <th>Report Date</th>
                            <th>Print Report</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>1.</td>
                            <td>#24102401</td>
                            <td>22nd Oct 2024</td>
                            <td>23nd Oct 2024</td>
                            <td><a class="print-btn" href="Z783.pdf" target="_blank">Print</a></td>
                        </tr> 
                    </tbody>
                </table>
            </section>
        </div>
    </div>
</body>
</html>

