-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Oct 24, 2024 at 06:08 AM
-- Server version: 10.11.9-MariaDB
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `u396395651_mediport`
--

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `profile_photo` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `email`, `username`, `password`, `profile_photo`) VALUES
(1, 'Vaidehi Mehta', 'vaidehi.mehta@gmail.com', 'vaidehi.mehta', '123456', 'img/profile/images.jpeg'),
(2, 'Nandini Sonania', 'nandini.sonania@gmail.com', 'nandini.sonania', '123456', 'img/profile/nandini.sonania.jpg'),
(3, 'Mohit Sharma', 'mohit.sharma@gmail.com', 'mohit.sharma', '123456', 'img/profile/mohit.sharma.jpeg'),
(4, 'Himanshu Dubey', 'himanshu.dubey@gmail.com', 'himanshu.dubey', '123456', 'img/profile/himanshu.dubey.jpg'),
(5, 'Zahid Khan', 'zahid.khan@gmail.com', 'zahid.khan', '123456', 'img/profile/zahid.khan.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
  -- Table structure for table ecg_parameters
CREATE TABLE ecg_parameters (
    subject INT NOT NULL,
    age INT,
    hr_mean DECIMAL(5,2),
    hr_std DECIMAL(5,2),
    amp_mean DECIMAL(5,2),
    amp_std DECIMAL(5,2),
    qrs_mean DECIMAL(5,2),
    qrs_std DECIMAL(5,2),
    pr_mean DECIMAL(5,2),
    pr_std DECIMAL(5,2),
    qt_mean DECIMAL(5,2),
    qt_std DECIMAL(5,2),
    st_level_mean DECIMAL(5,2),
    st_level_std DECIMAL(5,2),
    iso_level_mean DECIMAL(5,2),
    iso_level_std DECIMAL(5,2)
);

-- Insert ECG Data
INSERT INTO ecg_parameters (
    subject, age, hr_mean, hr_std, amp_mean, amp_std, qrs_mean, qrs_std, 
    pr_mean, pr_std, qt_mean, qt_std, st_level_mean, st_level_std, 
    iso_level_mean, iso_level_std
) 
VALUES
(1, 20, 68.89, 2.86, 2.68, 0.04, 0.08, 0.02, 0.24, 0.03, 0.60, 0.02, -0.11, 0.10, 2.96, 0.03),
(2, 24, 78.73, 1.87, 2.74, 0.05, 0.08, 0.01, 0.22, 0.04, 0.49, 0.02, 0.09, 0.05, 2.86, 0.03),
(3, 25, 75.40, 1.66, 3.22, 0.04, 0.08, 0.01, 0.17, 0.02, 0.47, 0.01, 0.09, 0.05, 2.96, 0.03),
(4, 26, 91.38, 1.68, 4.06, 0.04, 0.08, 0.01, 0.17, 0.02, 0.47, 0.01, 0.09, 0.05, 2.96, 0.03),
(5, 31, 107.49, 1.32, 2.81, 0.05, 0.08, 0.01, 0.15, 0.01, 0.35, 0.02, 0.39, 0.05, 2.98, 0.03),
(6, 33, 83.51, 1.57, 4.41, 0.04, 0.08, 0.02, 0.20, 0.01, 0.40, 0.01, 0.42, 0.05, 2.96, 0.03),
(7, 24, 67.99, 2.30, 2.76, 0.14, 0.08, 0.02, 0.26, 0.02, 0.26, 0.01, 0.10, 0.09, 2.98, 0.03),
(8, 27, 68.45, 1.96, 3.24, 0.02, 0.08, 0.01, 0.10, 0.02, 0.34, 0.01, -0.08, 0.32, 3.02, 0.11),
(9, 27, 65.85, 1.29, 3.24, 0.02, 0.11, 0.02, 0.10, 0.01);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
