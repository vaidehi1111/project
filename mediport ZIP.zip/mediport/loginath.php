<?php 
include 'connection.php';
session_start();
$email = $_POST['email'];
$password = $_POST['password'];
$sql = "SELECT * FROM user WHERE email = '$email' AND password = '$password' LIMIT 1";
$result = $conn->query($sql);
if ($result->num_rows > 0) 
{
    $row = $result->fetch_assoc();
    $_SESSION['user_id'] = $row['id'];
    $_SESSION['user_name'] = $row['name'];
    echo json_encode(array(
            "status" => 1,
            "message" => "Correct Email & Password! Now you are redirecting to Dashboard"
        ));
} 
else 
{
    echo json_encode(array(
            "status" => 1,
            "message" => "Incorrect Username or Password!"
        ));
} 

?>